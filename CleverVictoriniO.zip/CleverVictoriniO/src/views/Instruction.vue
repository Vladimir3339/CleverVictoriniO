

<script>

export default {

}
</script>


<template>
    <div>
        <p>Добро пожаловать на сайт-викторину CleverVictoriniO</p>
        <p>Иструкция:</p>
        <ul>
            <li>Главная задача - правильно ответьтить правильно на наибольшее количество вопросов подряд</li>
            <li>В разделе игра можно выбирать тему вопросов и их уровень сложности</li>
            <li>Существует рейтинг, где можно увидеть людей с наибольшим количеством в серии правильных ответов на вопросы</li>
            <li>Играть можно и без регистрации, но тогда прогресс не сохраняется и в рейтинге вы не отразитесь</li>

        </ul>
        <p>Удачной игры!</p>
        <img src="../assets/think_about.jpeg" alt="Надо будет думать">
    </div>
</template>


<style scoped>
 img{
    width: 30%;
    border-radius: 10%;
 }
div{
    font-size: 20px;
font-weight: bolder;
font-family: Verdana, Geneva, Tahoma, sans-serif;
color:#8B8BAE;
text-align: center;
}
p{font-style: italic;}
</style>